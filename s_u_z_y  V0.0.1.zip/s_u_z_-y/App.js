import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image, ImageBackground, Dimensions, Linking} from 'react-native'

const screenWidth = Dimensions.get('screen').width;
const screenHeight = Dimensions.get('screen').height;

const url = 'https://github.com/huwprosser';
const bom_url = 'http://www.bom.gov.au/places/qld/bundaberg/'
const school_url = 'https://schoolbox.shalomcollege.com/'
const read_url = 'https://api.bionic-reading.com/convert/'

export default class App extends React.Component {
  render() {
    return (
      <>
      <View style={styles.wallpaper}>
        <ImageBackground source={require("./assets/Default-Wallpaper.jpg")} resizeMode="cover" style={styles.image}/> 
      </View>
      <View style={styles.container}>
        <TouchableOpacity style={styles.button} onPress={()=>{Linking.openURL(read_url)}}>
        <Image source={require("./assets/Text-Icon-70x70.png")}/>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={()=>{Linking.openURL(bom_url)}}>
          <Image source={require("./assets/Weather-Icon-70x70.png")}/>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={()=>{Linking.openURL(url)}}>
          <Image source={require("./assets/GitHub-Icon-70x70.png")}/>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={()=>{Linking.openURL(school_url)}}>
          <Image source={require("./assets/Filler-Icon-70x70.png")}/>
        </TouchableOpacity>
      </View>
      </>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    alignItems: 'flex-end',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'flex-end',
    marginBottom: 20,
    marginRight: 60,
  },
  button: {
    height: 0,
    width: 0,
    backgroundColor: 'transparent',
    borderRadius: 20,
    padding: 10,
    marginBottom: 50,
    shadowColor: '#303838',
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 10,
    shadowOpacity: 0,
  },
  image: {
    flex: 1,
    width: screenWidth,
    height: screenHeight,
  },
});